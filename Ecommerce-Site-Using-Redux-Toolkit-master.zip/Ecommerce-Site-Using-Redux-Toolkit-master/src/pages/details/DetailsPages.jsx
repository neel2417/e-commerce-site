import React, { useState } from "react"
import "./details.css"
import { AiOutlinePlus, AiOutlineMinus, AiOutlineHeart } from "react-icons/ai"

export const DetailsPages = () => {
  return (
    <>
      <h1>DetailsPages</h1>
    </>
  )
}
