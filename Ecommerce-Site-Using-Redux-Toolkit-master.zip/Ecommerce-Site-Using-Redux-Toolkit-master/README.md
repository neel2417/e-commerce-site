Demo : https://648da94373a33f023dc9e1fb--jade-torrone-3d53da.netlify.app/ 

![screencapture-localhost-3000-2023-06-17-18_21_36](https://github.com/sunil9813/Ecommerce-Site-Using-Redux-Toolkit/assets/67497228/2f5dfaca-9bf9-4952-a71a-499c51aa6e15)
